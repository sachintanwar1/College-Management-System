# routes package initializer
# keep it minimal so route modules import correctly
__all__ = []
